#!/usr/bin/env python3
"""
experiments/exp4_fidelity_cliff.py
=====================================
Experiment 4: Fidelity cliff — QPE success probability vs truncation depth.

Reproduces Figure 4 of the paper.

Usage
-----
    python experiments/exp4_fidelity_cliff.py
    python experiments/exp4_fidelity_cliff.py --m 3 4 5 --shots 1000
"""

import argparse
import math
import os
import sys

import numpy as np

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from pfa_tqft import (
    exact_qft_matrix,
    phase_input_state,
    tqft_circuit,
)


def qpe_success_prob(m: int, d: int, n_shots: int = 1000, seed: int = 1) -> float:
    """
    Estimate P[|φ_hat - φ| ≤ 2^{-m}] by Monte Carlo simulation.

    Parameters
    ----------
    m       : int   — register size
    d       : int   — truncation depth (use d ≥ m for full QFT)
    n_shots : int   — number of Monte Carlo trials
    seed    : int   — random seed

    Returns
    -------
    float — estimated success probability
    """
    F   = exact_qft_matrix(m)
    rng = np.random.default_rng(seed)
    succ = 0
    for _ in range(n_shots):
        phi     = rng.uniform(0, 1)
        inp     = phase_input_state(m, phi)
        out     = F @ inp if d >= m else tqft_circuit(inp, m, d)
        pr      = np.abs(out) ** 2
        pr     /= pr.sum()           # renormalise for numerical safety
        idx_hat = rng.choice(2 ** m, p=pr)
        phi_hat = idx_hat / (2 ** m)
        err     = min(abs(phi_hat - phi), 1 - abs(phi_hat - phi))
        if err <= 2 ** (-m):
            succ += 1
    return succ / n_shots


def cliff_depth(m: int) -> int:
    """Analytically predicted fidelity-cliff depth: d_cliff* = ceil(log2(m)) + 2."""
    return math.ceil(math.log2(m)) + 2


def run_cliff_analysis(
    m_values: list[int] = (3, 4, 5),
    n_shots: int = 1000,
    seed: int = 1,
    verbose: bool = True,
) -> dict:
    """
    Compute success probability vs d for each m value.

    Returns
    -------
    dict: keys = m, values = list of (d, p_success)
    """
    results = {}
    full_qft_bound = 8 / math.pi ** 2   # theoretical lower bound for full QFT

    for m in m_values:
        d_cliff = cliff_depth(m)
        if verbose:
            print(f"\n  m = {m}  |  d_cliff* = {d_cliff}  "
                  f"|  Full QFT lower bound = {full_qft_bound:.4f}")
            print(f"  {'d':>3}  {'P_success':>10}  {'zone':>12}")
            print(f"  {'-'*30}")

        row = []
        for d in range(1, m + 2):   # m+1 = full QFT
            p = qpe_success_prob(m, d, n_shots, seed)
            if d < d_cliff:
                zone = "cliff ↓"
            elif d >= m:
                zone = "full QFT"
            else:
                zone = "plateau ✓"
            row.append((d, p))
            if verbose:
                marker = " ← d_cliff*" if d == d_cliff else ""
                print(f"  d={d:>2}: {p:>9.4f}  {zone:>12}{marker}")

        results[m] = row

    return results


def main() -> None:
    parser = argparse.ArgumentParser(
        description="Exp 4: Fidelity cliff analysis"
    )
    parser.add_argument("--m",     type=int, nargs="+", default=[3, 4, 5])
    parser.add_argument("--shots", type=int, default=1000)
    parser.add_argument("--seed",  type=int, default=1)
    args = parser.parse_args()

    print("=" * 60)
    print("Experiment 4: Fidelity Cliff")
    print(f"m values: {args.m}  |  shots: {args.shots}  |  seed: {args.seed}")
    print(f"Theoretical full QFT bound: 8/π² ≈ {8/math.pi**2:.4f}")
    print("=" * 60)

    results = run_cliff_analysis(args.m, args.shots, args.seed, verbose=True)

    print("\n" + "=" * 60)
    print("Summary — cliff depth formula: d_cliff* = ⌈log₂(m)⌉ + 2")
    for m in args.m:
        d_cliff = cliff_depth(m)
        row     = dict(results[m])
        p_full  = [p for d, p in results[m] if d >= m][0]
        p_cliff = [p for d, p in results[m] if d == d_cliff]
        print(f"  m={m}: d_cliff*={d_cliff}, "
              f"P(d_cliff*)={p_cliff[0]:.4f} if d_cliff available, "
              f"P(full QFT)={p_full:.4f}")
    print("=" * 60)


if __name__ == "__main__":
    main()
