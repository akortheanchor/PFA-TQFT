"""
tests/test_theorems.py
======================
Pytest suite validating every theorem, lemma, formula, and corrected
numerical value in the PFA-TQFT paper.

Run with:
    pytest tests/ -v

All tests use exact statevector simulation — no approximations.
"""

import math
import pytest
import numpy as np
from pfa_tqft import (
    exact_qft_matrix,
    phase_input_state,
    tqft_circuit,
    total_variation_distance,
    tvd_upper_bound,
    optimal_d_star,
    gate_count_tqft,
    gate_count_full_qft,
    tfim_ground_energy,
    rmse_model,
    noise_crossover_threshold,
    PLATFORMS,
)


# ═══════════════════════════════════════════════════════════════════════════════
# THEOREM 1 — TVD BOUND
# TV(P_φ, P_φ^d) ≤ π(m-d)/2^d   for all φ, m≥1, d≥1
# ═══════════════════════════════════════════════════════════════════════════════

class TestTheorem1_TVDBound:
    """Exhaustive validation of Theorem 1 by exact statevector simulation."""

    N_PHASES = 200   # random phases per (m, d) pair
    SEED     = 42

    @pytest.mark.parametrize("m,d", [
        (4, 1), (4, 2), (4, 3), (4, 4),
        (5, 1), (5, 2), (5, 3), (5, 4), (5, 5),
        (6, 2), (6, 4), (6, 6),
    ])
    def test_tvd_bound_holds(self, m: int, d: int) -> None:
        """Theorem 1: max TVD over random phases must not exceed bound."""
        F    = exact_qft_matrix(m)
        rng  = np.random.default_rng(self.SEED)
        phis = rng.uniform(0, 1, self.N_PHASES)
        bound = tvd_upper_bound(m, d)
        tvds  = []
        for phi in phis:
            inp  = phase_input_state(m, phi)
            Pf   = np.abs(F @ inp) ** 2
            Pt   = np.abs(tqft_circuit(inp, m, d)) ** 2
            tvds.append(total_variation_distance(Pf, Pt))
        max_tvd = max(tvds)
        assert max_tvd <= bound + 1e-10, (
            f"Theorem 1 VIOLATED: m={m}, d={d}, "
            f"max_TVD={max_tvd:.6f} > bound={bound:.6f}"
        )

    @pytest.mark.parametrize("m", [4, 5])
    def test_tvd_zero_at_full_depth(self, m: int) -> None:
        """At d = m (full QFT), TVD should be exactly 0."""
        F   = exact_qft_matrix(m)
        rng = np.random.default_rng(self.SEED)
        for phi in rng.uniform(0, 1, 50):
            inp  = phase_input_state(m, phi)
            Pf   = np.abs(F @ inp) ** 2
            Pt   = np.abs(tqft_circuit(inp, m, m)) ** 2
            tvd  = total_variation_distance(Pf, Pt)
            assert tvd < 1e-10, f"TVD at d=m should be 0, got {tvd}"

    def test_bound_tightness(self) -> None:
        """Max observed TVD/bound ratio should be in (0.1, 0.35) — tight but not violated."""
        F   = exact_qft_matrix(5)
        rng = np.random.default_rng(self.SEED)
        ratios = []
        for d in range(1, 5):
            phis = rng.uniform(0, 1, 300)
            bound = tvd_upper_bound(5, d)
            if bound < 1e-12:
                continue
            tvds = []
            for phi in phis:
                inp  = phase_input_state(5, phi)
                Pf   = np.abs(F @ inp) ** 2
                Pt   = np.abs(tqft_circuit(inp, 5, d)) ** 2
                tvds.append(total_variation_distance(Pf, Pt))
            ratios.append(max(tvds) / bound)
        max_ratio = max(ratios)
        assert max_ratio < 1.0,  f"Bound exceeded: ratio={max_ratio}"
        assert max_ratio > 0.05, f"Bound suspiciously loose: ratio={max_ratio}"


# ═══════════════════════════════════════════════════════════════════════════════
# DEFINITION 2 — PFA CRITERION
# d* = floor(log2(2π / ε₂q))
# ═══════════════════════════════════════════════════════════════════════════════

class TestPFACriterion:
    """Validate the PFA criterion formula and all platform d* values."""

    @pytest.mark.parametrize("eps_2q, expected_dstar", [
        (3e-3, 11),   # IBM Eagle r3
        (5e-4, 13),   # IBM Heron r2
        (3e-4, 14),   # IonQ Aria
        (2e-3, 11),   # IQM Garnet
    ])
    def test_dstar_formula(self, eps_2q: float, expected_dstar: int) -> None:
        """d* = floor(log2(2π/ε)) gives the correct value for each platform."""
        assert optimal_d_star(eps_2q) == expected_dstar, (
            f"d* wrong for ε={eps_2q}: expected {expected_dstar}, "
            f"got {optimal_d_star(eps_2q)}"
        )

    @pytest.mark.parametrize("eps_2q", [3e-3, 5e-4, 3e-4, 2e-3])
    def test_angle_condition(self, eps_2q: float) -> None:
        """Verify θ(d*) ≥ ε₂q and θ(d*+1) < ε₂q (defining condition of d*)."""
        d = optimal_d_star(eps_2q)
        theta_d   = 2 * math.pi / 2 ** d
        theta_d1  = 2 * math.pi / 2 ** (d + 1)
        assert theta_d  >= eps_2q, f"θ(d*)={theta_d:.4e} < ε={eps_2q:.4e}"
        assert theta_d1 <  eps_2q, f"θ(d*+1)={theta_d1:.4e} ≥ ε={eps_2q:.4e}"

    def test_platform_table_consistency(self) -> None:
        """All platform entries in PLATFORMS dict should pass the angle condition."""
        for name, plat in PLATFORMS.items():
            d  = plat["d_star"]
            e  = plat["eps_2q"]
            th = 2 * math.pi / 2 ** d
            assert th >= e, f"{name}: θ(d*)={th:.4e} < ε={e:.4e}"


# ═══════════════════════════════════════════════════════════════════════════════
# GATE-COUNT FORMULA  G(m, d) = Σⱼ max(0, min(d-1, m-j-1))
# ═══════════════════════════════════════════════════════════════════════════════

class TestGateCountFormula:
    """Verify gate count formula against direct enumeration."""

    def _enum_gates(self, m: int, d: int) -> int:
        """Count gates by direct loop over the circuit definition."""
        return sum(
            1
            for j in range(m)
            for k in range(2, m - j + 1)
            if k <= d
        )

    @pytest.mark.parametrize("m", [5, 10, 20, 30])
    def test_formula_matches_enumeration(self, m: int) -> None:
        """Formula must equal direct enumeration for every (m, d)."""
        for d in range(1, m + 1):
            formula = gate_count_tqft(m, d)
            exact   = self._enum_gates(m, d)
            assert formula == exact, (
                f"Gate count mismatch: m={m}, d={d}, "
                f"formula={formula}, exact={exact}"
            )

    @pytest.mark.parametrize("m,d,expected", [
        (30, 11, 245),
        (30, 13, 282),
        (30, 14, 299),
        (30, 30, 435),
        (5,  3,   7),
        (5,  5,  10),
    ])
    def test_specific_values(self, m: int, d: int, expected: int) -> None:
        """Spot-check specific values used in the paper."""
        assert gate_count_tqft(m, d) == expected, (
            f"G({m},{d}) = {gate_count_tqft(m,d)}, expected {expected}"
        )

    def test_full_qft_limit(self) -> None:
        """At d=m the gate count must equal the full QFT m(m-1)/2."""
        for m in [5, 10, 20, 30]:
            assert gate_count_tqft(m, m) == gate_count_full_qft(m), (
                f"G({m},{m}) ≠ {gate_count_full_qft(m)}"
            )


# ═══════════════════════════════════════════════════════════════════════════════
# TFIM GROUND ENERGY
# E0 = -3.427034 J  (n=4, J=1, h=0.5, open BC)
# ═══════════════════════════════════════════════════════════════════════════════

class TestTFIMGroundEnergy:
    """Validate the TFIM Hamiltonian diagonalisation."""

    def test_ground_energy_n4(self) -> None:
        """E0 for n=4, J=1, h=0.5, open BC must be -3.427034 J."""
        E0, _, _ = tfim_ground_energy(4, J=1.0, h=0.5)
        assert abs(E0 - (-3.427034)) < 1e-4, (
            f"TFIM E0 = {E0:.6f}, expected -3.427034"
        )

    def test_old_value_is_wrong(self) -> None:
        """Confirm -5.226 is NOT the correct ground energy for n=4."""
        E0, _, _ = tfim_ground_energy(4, J=1.0, h=0.5)
        assert abs(E0 - (-5.226)) > 0.5, (
            "TFIM E0 unexpectedly matches the old (incorrect) value -5.226"
        )

    def test_hamiltonian_is_hermitian(self) -> None:
        """H must be Hermitian."""
        _, evals, evecs = tfim_ground_energy(4)
        H = evecs @ np.diag(evals) @ evecs.conj().T
        assert np.allclose(H, H.conj().T, atol=1e-10), "H is not Hermitian"

    def test_ground_state_is_eigenstate(self) -> None:
        """Ground eigenvector must satisfy H|ψ₀⟩ = E₀|ψ₀⟩."""
        E0, evals, evecs = tfim_ground_energy(4)
        psi0 = evecs[:, 0]
        Z = np.array([[1,0],[0,-1]], dtype=complex)
        X = np.array([[0,1],[1,0]], dtype=complex)
        I = np.eye(2, dtype=complex)
        def kron_list(ops):
            r = ops[0]
            for o in ops[1:]: r = np.kron(r, o)
            return r
        H = np.zeros((16,16), dtype=complex)
        for i in range(3):
            ops=[I]*4; ops[i]=Z; ops[i+1]=Z; H-=kron_list(ops)
        for i in range(4):
            ops=[I]*4; ops[i]=X; H-=0.5*kron_list(ops)
        residual = np.linalg.norm(H @ psi0 - E0 * psi0)
        assert residual < 1e-10, f"Ground state residual = {residual}"


# ═══════════════════════════════════════════════════════════════════════════════
# COROLLARY — PHASE ACCURACY
# For α=0.05, m=30: d* = 11 satisfies TVD ≤ α
# ═══════════════════════════════════════════════════════════════════════════════

class TestCorollaryPhaseAccuracy:
    """Validate Corollary 4.4 numerical example."""

    def test_dstar11_satisfies_alpha_005_m30(self) -> None:
        """TVD bound at d*=11, m=30 must be ≤ α=0.05."""
        bound = tvd_upper_bound(30, 11)
        assert bound <= 0.05, (
            f"d*=11 does NOT satisfy α=0.05 at m=30: bound={bound:.4f}"
        )

    def test_dstar10_fails_alpha_005_m30(self) -> None:
        """TVD bound at d=10, m=30 must exceed α=0.05 (confirms d*=11 needed)."""
        bound = tvd_upper_bound(30, 10)
        assert bound > 0.05, (
            f"Unexpected: d=10 satisfies α=0.05 at m=30: bound={bound:.4f}"
        )

    @pytest.mark.parametrize("m", [10, 20, 30])
    def test_dstar_satisfies_alpha_for_all_m(self, m: int) -> None:
        """IBM Eagle d* must satisfy α=0.05 for m=10,20,30."""
        d = optimal_d_star(3e-3)   # IBM Eagle r3: d* = 11
        bound = tvd_upper_bound(m, d)
        assert bound <= 0.05, (
            f"IBM Eagle d*={d} fails α=0.05 at m={m}: bound={bound:.4f}"
        )


# ═══════════════════════════════════════════════════════════════════════════════
# NOISE-TRUNCATION SYNERGY THRESHOLD
# ε× ≈ 2.3×10⁻³  (analytical model, IBM Eagle r3, m=16, d*=11)
# ═══════════════════════════════════════════════════════════════════════════════

class TestNoiseSynergy:
    """Validate the noise-truncation cross-over threshold (analytical model)."""

    def test_crossover_threshold_ibm_eagle(self) -> None:
        """ε× should be approximately 2.3e-3 for IBM Eagle r3 (m=16, d*=11)."""
        eps_cross = noise_crossover_threshold(16, optimal_d_star(3e-3))
        assert 1.5e-3 < eps_cross < 3.5e-3, (
            f"ε× = {eps_cross:.3e} outside expected range [1.5e-3, 3.5e-3]"
        )

    def test_pfa_tqft_wins_above_threshold(self) -> None:
        """PFA-TQFT should outperform full QFT for ε₂q > ε×."""
        m, d = 16, optimal_d_star(3e-3)
        eps_cross = noise_crossover_threshold(m, d)
        # Test at 1.5× the threshold
        eps_test = 1.5 * eps_cross
        rmse_t, rmse_f = rmse_model(m, d, eps_test)
        assert rmse_t < rmse_f, (
            f"PFA-TQFT should win at ε={eps_test:.3e}, "
            f"but RMSE_PFA={rmse_t:.4e} ≥ RMSE_Full={rmse_f:.4e}"
        )

    def test_full_qft_wins_below_threshold(self) -> None:
        """Full QFT should outperform PFA-TQFT for ε₂q << ε×."""
        m, d = 16, optimal_d_star(3e-3)
        eps_cross = noise_crossover_threshold(m, d)
        eps_test  = 0.1 * eps_cross   # well below threshold
        rmse_t, rmse_f = rmse_model(m, d, eps_test)
        assert rmse_f < rmse_t, (
            f"Full QFT should win at ε={eps_test:.3e}, "
            f"but RMSE_Full={rmse_f:.4e} ≥ RMSE_PFA={rmse_t:.4e}"
        )


# ═══════════════════════════════════════════════════════════════════════════════
# QPE SUCCESS PROBABILITY — FIDELITY CLIFF
# ═══════════════════════════════════════════════════════════════════════════════

class TestFidelityCliff:
    """Verify the fidelity cliff: success probability vs truncation depth."""

    SHOTS = 800
    SEED  = 7

    def _success_prob(self, m: int, d: int) -> float:
        F   = exact_qft_matrix(m)
        rng = np.random.default_rng(self.SEED)
        succ = 0
        for _ in range(self.SHOTS):
            phi     = rng.uniform(0, 1)
            inp     = phase_input_state(m, phi)
            out     = F @ inp if d >= m else tqft_circuit(inp, m, d)
            pr      = np.abs(out) ** 2
            idx_hat = rng.choice(2 ** m, p=pr)
            phi_hat = idx_hat / (2 ** m)
            err     = min(abs(phi_hat - phi), 1 - abs(phi_hat - phi))
            if err <= 2 ** (-m):
                succ += 1
        return succ / self.SHOTS

    def test_full_qft_achieves_high_success(self) -> None:
        """Full QFT (d=m) should achieve P_success ≥ 0.5 (well above 8/π²≈0.81 theoretically)."""
        p = self._success_prob(4, 4)   # d = m = 4 (full QFT)
        assert p >= 0.5, f"Full QFT success probability {p:.3f} unexpectedly low"

    def test_success_increases_with_depth(self) -> None:
        """Success probability should be non-decreasing as d increases (on average)."""
        m = 4
        probs = [self._success_prob(m, d) for d in range(1, m + 1)]
        # Allow minor fluctuations but overall trend must be increasing
        assert probs[-1] >= probs[0], (
            f"Success probability did not increase from d=1 to d={m}: {probs}"
        )


# ═══════════════════════════════════════════════════════════════════════════════
# PLATFORM TABLE INTEGRITY
# ═══════════════════════════════════════════════════════════════════════════════

class TestPlatformTable:
    """Verify every entry in the PLATFORMS dictionary."""

    def test_all_platforms_present(self) -> None:
        expected = {"IBM Eagle r3", "IBM Heron r2", "IonQ Aria", "IQM Garnet"}
        assert set(PLATFORMS.keys()) == expected

    @pytest.mark.parametrize("name,expected_dstar,expected_gates", [
        ("IBM Eagle r3", 11, 245),
        ("IBM Heron r2", 13, 282),
        ("IonQ Aria",    14, 299),
        ("IQM Garnet",   11, 245),
    ])
    def test_platform_values(
        self, name: str, expected_dstar: int, expected_gates: int
    ) -> None:
        p = PLATFORMS[name]
        assert p["d_star"]     == expected_dstar, \
            f"{name}: d*={p['d_star']}, expected {expected_dstar}"
        assert p["gates_tqft"] == expected_gates, \
            f"{name}: G={p['gates_tqft']}, expected {expected_gates}"

    def test_gate_reductions_in_range(self) -> None:
        """All platforms should have 30–50% reduction at m=30."""
        for name, p in PLATFORMS.items():
            r = p["reduction_pct"]
            assert 25 <= r <= 50, f"{name}: reduction {r:.1f}% outside [25,50]%"
