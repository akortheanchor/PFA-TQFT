#!/usr/bin/env python3
"""
experiments/exp1_tvd_validation.py
===================================
Experiment 1: Validate Theorem 1 (TVD bound) by exact statevector simulation.

TV(P_φ, P_φ^d) ≤ π(m-d)/2^d   for all φ ∈ [0,1), m ≥ 1, d ≥ 1.

Reproduces Figure 2(a) of the paper.

Usage
-----
    python experiments/exp1_tvd_validation.py
    python experiments/exp1_tvd_validation.py --m 5 --n-phases 500
    python experiments/exp1_tvd_validation.py --save-csv results/tvd_data.csv
"""

import argparse
import csv
import os
import sys

import numpy as np

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from pfa_tqft import (
    exact_qft_matrix,
    phase_input_state,
    tqft_circuit,
    total_variation_distance,
    tvd_upper_bound,
)


def run_tvd_experiment(
    m_values: list[int] = (4, 5, 6),
    n_phases: int = 500,
    seed: int = 42,
    verbose: bool = True,
) -> dict:
    """
    Compute max TVD over random phases for each (m, d) pair.

    Returns
    -------
    results : dict
        keys = (m, d), values = {'tvd_max', 'tvd_mean', 'bound', 'ratio'}
    """
    rng     = np.random.default_rng(seed)
    results = {}

    for m in m_values:
        F = exact_qft_matrix(m)
        if verbose:
            print(f"\n  m = {m}")
            print(f"  {'d':>3}  {'max TVD':>10}  {'bound':>10}  {'ratio':>7}  status")
            print(f"  {'-'*48}")

        for d in range(1, m + 1):
            phis  = rng.uniform(0, 1, n_phases)
            bound = tvd_upper_bound(m, d)
            tvds  = []
            for phi in phis:
                inp  = phase_input_state(m, phi)
                Pf   = np.abs(F @ inp) ** 2
                Pt   = np.abs(tqft_circuit(inp, m, d)) ** 2
                tvds.append(total_variation_distance(Pf, Pt))

            max_tvd  = float(np.max(tvds))
            mean_tvd = float(np.mean(tvds))
            ratio    = max_tvd / bound if bound > 1e-12 else 0.0
            ok       = max_tvd <= bound + 1e-10

            results[(m, d)] = {
                "m"       : m,
                "d"       : d,
                "tvd_max" : max_tvd,
                "tvd_mean": mean_tvd,
                "bound"   : bound,
                "ratio"   : ratio,
                "pass"    : ok,
            }

            if verbose:
                status = "PASS ✓" if ok else "FAIL ✗"
                print(f"  d={d:>2}: max={max_tvd:>10.6f}  "
                      f"bound={bound:>10.6f}  ratio={ratio:>6.3f}  {status}")

    return results


def save_csv(results: dict, path: str) -> None:
    os.makedirs(os.path.dirname(path), exist_ok=True)
    with open(path, "w", newline="") as f:
        w = csv.DictWriter(f, fieldnames=["m", "d", "tvd_max", "tvd_mean",
                                          "bound", "ratio", "pass"])
        w.writeheader()
        w.writerows(results.values())
    print(f"\n  Saved: {path}")


def main() -> None:
    parser = argparse.ArgumentParser(
        description="Exp 1: TVD bound validation (Theorem 1)"
    )
    parser.add_argument("--m",        type=int, nargs="+", default=[4, 5, 6],
                        help="Register sizes to test")
    parser.add_argument("--n-phases", type=int, default=500,
                        help="Random phases per (m,d) pair")
    parser.add_argument("--seed",     type=int, default=42)
    parser.add_argument("--save-csv", type=str, default=None,
                        help="Save results to CSV file")
    args = parser.parse_args()

    print("=" * 60)
    print("Experiment 1: Theorem 1 TVD Bound Validation")
    print(f"m values: {args.m}  |  n_phases: {args.n_phases}  |  seed: {args.seed}")
    print("=" * 60)

    results = run_tvd_experiment(args.m, args.n_phases, args.seed, verbose=True)

    n_pass = sum(r["pass"] for r in results.values())
    n_total = len(results)
    max_ratio = max(r["ratio"] for r in results.values()
                    if r["bound"] > 1e-12)

    print("\n" + "=" * 60)
    print(f"Result: {n_pass}/{n_total} checks passed")
    print(f"Max TVD/bound ratio: {max_ratio:.4f} (bound tightness indicator)")
    print("Theorem 1 status:", "ALL PASS ✓" if n_pass == n_total else "SOME FAIL ✗")
    print("=" * 60)

    if args.save_csv:
        save_csv(results, args.save_csv)


if __name__ == "__main__":
    main()
