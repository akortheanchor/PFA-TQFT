"""
pfa_tqft.core
=============
Exact quantum simulation primitives for the PFA-TQFT paper.

All functions use pure NumPy / SciPy — no external quantum SDK required.
The full 2^m-dimensional complex statevector is maintained exactly;
no approximations are made during circuit simulation.

Corrected values (vs. earlier preprint versions)
-------------------------------------------------
* d* formula: d* = floor(log2(2π/ε₂q))  — NOT floor(log2(1/ε₂q))
* Gate count:  G(m,d) = Σⱼ max(0, min(d-1, m-j-1))  — closed form below
* TFIM E₀:     −3.427034 J  (n=4, J=1, h=0.5, open BC)
"""

from __future__ import annotations
import math
import numpy as np
from scipy.linalg import eigh as sp_eigh
from typing import Tuple


# ═══════════════════════════════════════════════════════════════════════════════
# SECTION 1 — EXACT QFT / TQFT SIMULATION
# ═══════════════════════════════════════════════════════════════════════════════

def exact_qft_matrix(m: int) -> np.ndarray:
    """
    Build the exact 2^m × 2^m QFT unitary.

    QFT_N |x⟩ = (1/√N) Σ_{y=0}^{N-1} exp(2πi·xy/N) |y⟩,  N = 2^m.

    Parameters
    ----------
    m : int
        Number of qubits (register size).

    Returns
    -------
    F : ndarray, shape (2^m, 2^m), dtype complex128
        Unitary matrix of the m-qubit QFT.
    """
    N   = 2 ** m
    idx = np.arange(N, dtype=np.float64)
    W   = np.exp(2j * np.pi * np.outer(idx, idx) / N)
    return W / np.sqrt(N)


def phase_input_state(m: int, phi: float) -> np.ndarray:
    """
    Prepare the QPE control-register state after controlled-U^{2^k} operations.

    For eigenphase φ the state is:
        |ψ_φ⟩ = (1/√N) Σ_{j=0}^{N-1} exp(2πi·j·φ) |j⟩

    Parameters
    ----------
    m   : int   — register size (m qubits)
    phi : float — eigenphase φ ∈ [0, 1)

    Returns
    -------
    state : ndarray, shape (2^m,), dtype complex128
    """
    N = 2 ** m
    j = np.arange(N, dtype=np.float64)
    return np.exp(2j * np.pi * j * phi) / np.sqrt(N)


def apply_hadamard(state: np.ndarray, m: int, qubit: int) -> np.ndarray:
    """Apply a Hadamard gate to `qubit` in an m-qubit statevector."""
    N  = 2 ** m
    ns = np.zeros(N, dtype=complex)
    for idx in range(N):
        bits       = list(format(idx, f"0{m}b"))
        b          = int(bits[qubit])
        s_inv      = 1.0 / np.sqrt(2)
        for nb in (0, 1):
            bits2          = bits[:]
            bits2[qubit]   = str(nb)
            new_idx        = int("".join(bits2), 2)
            ns[new_idx]   += state[idx] * (-1) ** (b * nb) * s_inv
    return ns


def apply_ctrl_phase(
    state: np.ndarray, m: int, ctrl: int, tgt: int, k: int
) -> np.ndarray:
    """
    Apply controlled-R_k gate to an m-qubit statevector.

    R_k = diag(1, exp(2πi / 2^k)) acts on the target qubit when the
    control qubit is |1⟩.

    Parameters
    ----------
    state : ndarray, shape (2^m,)
    m     : int — total qubits
    ctrl  : int — control qubit index (0 = MSB)
    tgt   : int — target qubit index
    k     : int — rotation order (R_k has angle 2π/2^k)
    """
    phase = np.exp(2j * np.pi / (2 ** k))
    ns    = state.copy()
    for idx in range(2 ** m):
        bits = format(idx, f"0{m}b")
        if bits[ctrl] == "1" and bits[tgt] == "1":
            ns[idx] *= phase
    return ns


def apply_swap(
    state: np.ndarray, m: int, q1: int, q2: int
) -> np.ndarray:
    """Swap qubits q1 and q2 in an m-qubit statevector."""
    N  = 2 ** m
    ns = np.zeros(N, dtype=complex)
    for idx in range(N):
        bits       = list(format(idx, f"0{m}b"))
        bits[q1], bits[q2] = bits[q2], bits[q1]
        ns[int("".join(bits), 2)] = state[idx]
    return ns


def tqft_circuit(state: np.ndarray, m: int, d: int) -> np.ndarray:
    """
    Apply the PFA-TQFT_d circuit to `state`.

    Only controlled-R_k gates with k ≤ d are retained.
    Gates with k > d are omitted (PFA criterion).

    Parameters
    ----------
    state : ndarray, shape (2^m,) — input quantum state
    m     : int — register size
    d     : int — truncation depth (use d >= m for full QFT)

    Returns
    -------
    out : ndarray, shape (2^m,) — output state after PFA-TQFT_d
    """
    s = state.copy()
    # Stage j: Hadamard on qubit j, then controlled-R_k for k=2..min(d, m-j)
    for j in range(m):
        s = apply_hadamard(s, m, j)
        for k in range(2, m - j + 1):
            if k <= d:
                s = apply_ctrl_phase(s, m, j + k - 1, j, k)
    # Bit-reversal SWAP permutation
    for i in range(m // 2):
        s = apply_swap(s, m, i, m - 1 - i)
    return s


# ═══════════════════════════════════════════════════════════════════════════════
# SECTION 2 — ERROR METRICS AND BOUNDS
# ═══════════════════════════════════════════════════════════════════════════════

def total_variation_distance(p: np.ndarray, q: np.ndarray) -> float:
    """
    Total variation distance between two probability vectors.

    TV(p, q) = (1/2) Σ_x |p_x - q_x|

    Parameters
    ----------
    p, q : ndarray — probability vectors (must sum to 1)

    Returns
    -------
    float — TV distance in [0, 1]
    """
    return 0.5 * float(np.sum(np.abs(p - q)))


def tvd_upper_bound(m: int, d: int) -> float:
    """
    Theorem 1 upper bound on TV(P_φ, P_φ^d).

    TV(P_φ, P_φ^d) ≤ π(m - d) / 2^d   for all φ, m ≥ 1, d ≥ 1.

    This is the central result of the paper. The bound is tight
    to within a constant factor (see Remark A.1 in the appendix).

    Parameters
    ----------
    m : int — register size
    d : int — truncation depth

    Returns
    -------
    float — upper bound on TVD
    """
    return np.pi * max(m - d, 0) / (2 ** d)


# ═══════════════════════════════════════════════════════════════════════════════
# SECTION 3 — PFA CRITERION AND HARDWARE CALIBRATION
# ═══════════════════════════════════════════════════════════════════════════════

def optimal_d_star(eps_2q: float) -> int:
    """
    PFA Criterion (Definition 2): hardware-optimal truncation depth.

        d* = floor( log2(2π / ε₂q) )

    This is the largest k such that the rotation angle θ_k = 2π/2^k ≥ ε₂q.
    Gates with k > d* contribute less phase accuracy than the noise they
    introduce, so omitting them reduces total error.

    Parameters
    ----------
    eps_2q : float — two-qubit gate depolarizing error rate

    Returns
    -------
    int — optimal truncation depth d*

    Examples
    --------
    >>> optimal_d_star(3e-3)   # IBM Eagle r3
    11
    >>> optimal_d_star(5e-4)   # IBM Heron r2
    13
    >>> optimal_d_star(3e-4)   # IonQ Aria
    14
    """
    return int(math.floor(math.log2(2 * math.pi / eps_2q)))


def gate_count_tqft(m: int, d: int) -> int:
    """
    Exact two-qubit gate count for PFA-TQFT_d on m control qubits.

    G(m, d) = Σ_{j=0}^{m-1}  max(0,  min(d-1,  m-j-1))

    This counts only controlled-phase gates (not Hadamard gates).

    Parameters
    ----------
    m : int — register size
    d : int — truncation depth

    Returns
    -------
    int — number of two-qubit gates

    Notes
    -----
    For d ≥ m this returns the full-QFT count m(m-1)/2.
    Verified by exhaustive enumeration for all m ∈ {5,10,20,30}.
    """
    return sum(max(0, min(d - 1, m - j - 1)) for j in range(m))


def gate_count_full_qft(m: int) -> int:
    """
    Full-QFT two-qubit gate count: m*(m-1)//2.

    Parameters
    ----------
    m : int — register size

    Returns
    -------
    int — number of two-qubit gates in the full QFT
    """
    return m * (m - 1) // 2


# ═══════════════════════════════════════════════════════════════════════════════
# SECTION 4 — TFIM HAMILTONIAN
# ═══════════════════════════════════════════════════════════════════════════════

def tfim_ground_energy(
    n: int, J: float = 1.0, h: float = 0.5
) -> Tuple[float, np.ndarray, np.ndarray]:
    """
    Exact ground energy of the 1D transverse-field Ising model (open BC).

    H = -J Σ_i Z_i Z_{i+1}  -  h Σ_i X_i

    Parameters
    ----------
    n : int   — number of sites
    J : float — Ising coupling (default 1.0)
    h : float — transverse field (default 0.5)

    Returns
    -------
    E0     : float             — ground state energy
    evals  : ndarray, (2^n,)   — full spectrum (ascending)
    evecs  : ndarray, (2^n, 2^n) — eigenvectors (columns)

    Notes
    -----
    For n=4, J=1, h=0.5, open BC: E0 = -3.427034 J  (exact).
    The earlier preprint value of -5.226 J was incorrect.

    Examples
    --------
    >>> E0, _, _ = tfim_ground_energy(4)
    >>> round(E0, 4)
    -3.427
    """
    Z = np.array([[1,  0], [0, -1]], dtype=complex)
    X = np.array([[0,  1], [1,  0]], dtype=complex)
    I = np.eye(2, dtype=complex)

    def kron_list(ops):
        result = ops[0]
        for op in ops[1:]:
            result = np.kron(result, op)
        return result

    dim  = 2 ** n
    H    = np.zeros((dim, dim), dtype=complex)
    # ZZ terms (open BC: i=0..n-2)
    for i in range(n - 1):
        ops    = [I] * n
        ops[i] = Z; ops[i + 1] = Z
        H     -= J * kron_list(ops)
    # X terms
    for i in range(n):
        ops    = [I] * n
        ops[i] = X
        H     -= h * kron_list(ops)

    evals, evecs = sp_eigh(H)
    return float(evals[0]), evals, evecs


# ═══════════════════════════════════════════════════════════════════════════════
# SECTION 5 — RMSE MODEL AND NOISE-TRUNCATION SYNERGY
# ═══════════════════════════════════════════════════════════════════════════════

#: Noise coefficient calibrated to IBM Eagle r3 at m=16, ε₂q=1e-3.
#: RMSE_noise = G(m,d) * eps_2q * C_NOISE
C_NOISE: float = 0.033


def rmse_model(
    m: int,
    d: int,
    eps_2q: float,
    c_noise: float = C_NOISE,
) -> Tuple[float, float]:
    """
    Analytical RMSE model under depolarizing noise (Appendix E, Eq. E.1).

    RMSE² = σ_baseline² + σ_approx² + σ_noise²

    where:
        σ_baseline = 2^{-m} / √3          (quantum precision limit)
        σ_approx   = TV(m,d) / √3          (truncation error spread)
        σ_noise_t  = G(m,d) · ε₂q · c     (depolarizing noise, PFA-TQFT)
        σ_noise_f  = G_full  · ε₂q · c     (depolarizing noise, full QFT)

    Parameters
    ----------
    m       : int   — register size
    d       : int   — truncation depth
    eps_2q  : float — two-qubit gate error rate
    c_noise : float — noise coefficient (default C_NOISE = 0.033)

    Returns
    -------
    rmse_tqft : float — RMSE for PFA-TQFT_d
    rmse_full : float — RMSE for full QFT (d = m)

    Notes
    -----
    This is an **analytical model** calibrated to IBM Eagle r3 at m=16,
    ε₂q=1e-3.  It is NOT based on direct hardware experiment.
    Hardware validation is listed as future work.
    """
    G_t   = gate_count_tqft(m, d)
    G_f   = gate_count_full_qft(m)
    tv    = tvd_upper_bound(m, d)
    base  = 2.0 ** (-m) / math.sqrt(3)
    s_a   = tv / math.sqrt(3)
    s_n_t = G_t * eps_2q * c_noise
    s_n_f = G_f * eps_2q * c_noise
    return (
        math.sqrt(base ** 2 + s_a ** 2 + s_n_t ** 2),
        math.sqrt(base ** 2 + s_n_f ** 2),
    )


def noise_crossover_threshold(
    m: int,
    d: int,
    c_noise: float = C_NOISE,
) -> float:
    """
    Analytical noise-truncation synergy cross-over threshold (Appendix G, Eq. G.1).

    ε× = (TV / √3) / (c · √(G_full² - G(m,d)²))

    Above this threshold PFA-TQFT_d outperforms full QFT under the
    analytical RMSE model.

    Parameters
    ----------
    m       : int   — register size
    d       : int   — truncation depth (use d* for the optimal threshold)
    c_noise : float — noise coefficient (default C_NOISE)

    Returns
    -------
    float — cross-over threshold ε×

    Notes
    -----
    For IBM Eagle r3 (m=16, d*=11):  ε× ≈ 2.3×10⁻³.
    This is a **model-derived** value; direct hardware validation
    is a direction for future work.

    Examples
    --------
    >>> round(noise_crossover_threshold(16, optimal_d_star(3e-3)), 4)
    0.0023
    """
    G_f = gate_count_full_qft(m)
    G_t = gate_count_tqft(m, d)
    tv  = tvd_upper_bound(m, d)
    denom = c_noise * math.sqrt(max(G_f ** 2 - G_t ** 2, 1e-12))
    return (tv / math.sqrt(3)) / denom
