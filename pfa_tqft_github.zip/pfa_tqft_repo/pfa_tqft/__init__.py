"""
pfa_tqft — Phase-Fidelity-Aware Truncated Quantum Fourier Transform
====================================================================
Reproducibility package for:

    "Phase-Fidelity-Aware Truncated Quantum Fourier Transform
     for Scalable Phase Estimation on NISQ Hardware"

    Akoramurthy S, Surendiran B
    Department of ECE, NIT Puducherry, India
    Quantum journal (submitted 2025)

Public API
----------
    from pfa_tqft import (
        exact_qft_matrix,
        phase_input_state,
        tqft_circuit,
        total_variation_distance,
        tvd_upper_bound,
        optimal_d_star,
        gate_count_tqft,
        gate_count_full_qft,
        tfim_ground_energy,
        PLATFORMS,
    )
"""

from .core import (
    exact_qft_matrix,
    phase_input_state,
    apply_hadamard,
    apply_ctrl_phase,
    apply_swap,
    tqft_circuit,
    total_variation_distance,
    tvd_upper_bound,
    optimal_d_star,
    gate_count_tqft,
    gate_count_full_qft,
    tfim_ground_energy,
    rmse_model,
    noise_crossover_threshold,
)
from .platforms import PLATFORMS

__version__ = "1.0.0"
__author__  = "Akoramurthy S, Surendiran B"
__license__ = "MIT"

__all__ = [
    "exact_qft_matrix",
    "phase_input_state",
    "apply_hadamard",
    "apply_ctrl_phase",
    "apply_swap",
    "tqft_circuit",
    "total_variation_distance",
    "tvd_upper_bound",
    "optimal_d_star",
    "gate_count_tqft",
    "gate_count_full_qft",
    "tfim_ground_energy",
    "rmse_model",
    "noise_crossover_threshold",
    "PLATFORMS",
]
