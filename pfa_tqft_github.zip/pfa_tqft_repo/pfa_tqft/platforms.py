"""
pfa_tqft.platforms
==================
Validated hardware platform parameters for PFA-TQFT design rules.

All d* values are computed from the PFA criterion:

    d* = floor(log2(2π / ε₂q))

and verified against the exact gate-angle condition
θ_{d*} = 2π/2^{d*} ≥ ε₂q > 2π/2^{d*+1} = θ_{d*+1}.

Gate counts use the exact formula G(m,d) = Σⱼ max(0, min(d-1, m-j-1)).

All values are for m = 30 control qubits unless otherwise noted.

Sources
-------
IBM Quantum (2024). IBM Eagle r3 and Heron r2 system specifications.
    https://www.ibm.com/quantum
IonQ (2024). IonQ Aria system specifications.
    https://ionq.com/technology
IQM (2024). IQM Garnet system specifications.
    https://meetiqm.com
"""

from __future__ import annotations
from typing import Dict, Any
import math


def _validate(name: str, eps_2q: float, d_star: int) -> None:
    """Assert that d_star satisfies the PFA criterion."""
    theta_d   = 2 * math.pi / 2 ** d_star
    theta_d1  = 2 * math.pi / 2 ** (d_star + 1)
    assert theta_d  >= eps_2q, (
        f"{name}: θ(d*)={theta_d:.4e} < ε₂q={eps_2q:.4e} — criterion violated"
    )
    assert theta_d1 <  eps_2q, (
        f"{name}: θ(d*+1)={theta_d1:.4e} ≥ ε₂q={eps_2q:.4e} — d* too small"
    )


def _gate_count(m: int, d: int) -> int:
    return sum(max(0, min(d - 1, m - j - 1)) for j in range(m))


def _build_platform(
    name: str,
    eps_2q: float,
    m: int = 30,
) -> Dict[str, Any]:
    """Build a validated platform dictionary."""
    d_star = int(math.floor(math.log2(2 * math.pi / eps_2q)))
    _validate(name, eps_2q, d_star)
    g_tqft = _gate_count(m, d_star)
    g_full = m * (m - 1) // 2
    return {
        "name"         : name,
        "eps_2q"       : eps_2q,
        "d_star"       : d_star,
        "gates_tqft"   : g_tqft,
        "gates_full"   : g_full,
        "reduction_pct": 100.0 * (1 - g_tqft / g_full),
        "m"            : m,
        "theta_dstar"  : 2 * math.pi / 2 ** d_star,
        "tvd_bound"    : math.pi * max(m - d_star, 0) / 2 ** d_star,
    }


#: Validated platform data (m = 30 qubits).
#: All d* values confirmed by exact PFA criterion check at module import.
PLATFORMS: Dict[str, Dict[str, Any]] = {
    p["name"]: p for p in [
        _build_platform("IBM Eagle r3",  3e-3),
        _build_platform("IBM Heron r2",  5e-4),
        _build_platform("IonQ Aria",     3e-4),
        _build_platform("IQM Garnet",    2e-3),
    ]
}

# ── Convenience list (ordered by ε₂q descending) ─────────────────────────────
PLATFORM_LIST = [
    PLATFORMS["IBM Eagle r3"],
    PLATFORMS["IQM Garnet"],
    PLATFORMS["IBM Heron r2"],
    PLATFORMS["IonQ Aria"],
]


def print_platform_table(m: int = 30) -> None:
    """Print a formatted table of platform parameters."""
    hdr = f"{'Platform':<16} {'ε₂q':>8} {'d*':>4} {'Gates':>10} {'Reduction':>10} {'TVD bound':>10}"
    print(hdr)
    print("-" * len(hdr))
    for plat in [
        _build_platform("IBM Eagle r3", 3e-3, m),
        _build_platform("IQM Garnet",   2e-3, m),
        _build_platform("IBM Heron r2", 5e-4, m),
        _build_platform("IonQ Aria",    3e-4, m),
    ]:
        print(
            f"{plat['name']:<16} "
            f"{plat['eps_2q']:>8.0e} "
            f"{plat['d_star']:>4d} "
            f"{plat['gates_tqft']:>5d}/{plat['gates_full']:<4d} "
            f"{plat['reduction_pct']:>9.1f}% "
            f"{plat['tvd_bound']:>10.5f}"
        )


if __name__ == "__main__":
    print(f"\nPFA-TQFT Platform Design Rules (m = 30)\n")
    print_platform_table(30)
    print()
