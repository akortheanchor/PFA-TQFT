#!/usr/bin/env python3
"""
experiments/exp2_platform_rules.py
====================================
Experiment 2: Hardware-calibrated PFA-TQFT design rules (Table 1 / Figure 5).

Computes d*, gate counts, and TVD bounds for all four NISQ platforms.
Reproduces Table 1 and Figure 5 of the paper.

Usage
-----
    python experiments/exp2_platform_rules.py
    python experiments/exp2_platform_rules.py --m 50
"""

import argparse
import os
import sys

import numpy as np

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from pfa_tqft import (
    optimal_d_star,
    gate_count_tqft,
    gate_count_full_qft,
    tvd_upper_bound,
    PLATFORMS,
)
from pfa_tqft.platforms import print_platform_table


# Raw platform specs
_PLATFORM_SPECS = [
    ("IBM Eagle r3",  3e-3),
    ("IBM Heron r2",  5e-4),
    ("IonQ Aria",     3e-4),
    ("IQM Garnet",    2e-3),
]


def run_platform_analysis(m: int = 30) -> list[dict]:
    """
    Compute PFA-TQFT design rules for all platforms at register size m.

    Returns list of dicts with keys:
        name, eps_2q, d_star, gates_tqft, gates_full,
        reduction_pct, tvd_bound, theta_dstar
    """
    results = []
    for name, eps in _PLATFORM_SPECS:
        d     = optimal_d_star(eps)
        g_t   = gate_count_tqft(m, d)
        g_f   = gate_count_full_qft(m)
        theta = 2 * np.pi / 2 ** d
        results.append({
            "name"         : name,
            "eps_2q"       : eps,
            "d_star"       : d,
            "gates_tqft"   : g_t,
            "gates_full"   : g_f,
            "reduction_pct": 100.0 * (1 - g_t / g_f),
            "tvd_bound"    : tvd_upper_bound(m, d),
            "theta_dstar"  : theta,
        })
    return results


def verify_angle_conditions(results: list[dict]) -> None:
    """Assert PFA criterion angle condition for each platform."""
    print("\nAngle condition verification  (θ(d*) ≥ ε₂q > θ(d*+1)):")
    all_ok = True
    for r in results:
        d      = r["d_star"]
        eps    = r["eps_2q"]
        theta  = r["theta_dstar"]
        theta1 = 2 * np.pi / 2 ** (d + 1)
        ok1    = theta  >= eps
        ok2    = theta1 <  eps
        ok     = ok1 and ok2
        all_ok &= ok
        print(f"  {r['name']:<16}: θ(d*)={theta:.3e} {'≥' if ok1 else '<'} "
              f"ε={eps:.3e} {'>' if ok2 else '≤'} θ(d*+1)={theta1:.3e}  "
              f"[{'PASS' if ok else 'FAIL'}]")
    if all_ok:
        print("  All platforms: PASS ✓")


def print_design_table(results: list[dict]) -> None:
    """Print formatted Table 1 equivalent."""
    print(f"\n{'Platform':<16} {'ε₂q':>8} {'d*':>4} "
          f"{'Gates':>10} {'Reduction':>10} {'TVD bound':>10}")
    print("-" * 64)
    for r in results:
        print(
            f"{r['name']:<16} "
            f"{r['eps_2q']:>8.0e} "
            f"{r['d_star']:>4d} "
            f"{r['gates_tqft']:>5d}/{r['gates_full']:<4d} "
            f"{r['reduction_pct']:>9.1f}% "
            f"{r['tvd_bound']:>10.5f}"
        )


def show_reduction_vs_m(m_values: list[int]) -> None:
    """Show how gate reduction % evolves with m for each platform."""
    print(f"\nGate reduction (%) vs register size m:")
    header = f"{'Platform':<16}" + "".join(f"  m={m:>2}" for m in m_values)
    print(header)
    print("-" * len(header))
    for name, eps in _PLATFORM_SPECS:
        d = optimal_d_star(eps)
        row = f"{name:<16}"
        for m in m_values:
            g_t = gate_count_tqft(m, d)
            g_f = gate_count_full_qft(m)
            row += f"  {100*(1-g_t/g_f):>5.1f}%"
        print(row)


def main() -> None:
    parser = argparse.ArgumentParser(
        description="Exp 2: Platform-specific PFA-TQFT design rules"
    )
    parser.add_argument("--m", type=int, default=30,
                        help="Register size for gate count analysis")
    args = parser.parse_args()

    print("=" * 64)
    print("Experiment 2: Platform-Specific PFA-TQFT Design Rules")
    print(f"Register size: m = {args.m}")
    print("=" * 64)

    results = run_platform_analysis(args.m)
    verify_angle_conditions(results)
    print_design_table(results)
    show_reduction_vs_m([10, 20, 30, 50])

    print("\n\nSummary:")
    print(f"  Gate reduction range at m={args.m}: "
          f"{min(r['reduction_pct'] for r in results):.1f}–"
          f"{max(r['reduction_pct'] for r in results):.1f}%")
    print(f"  d* range: {min(r['d_star'] for r in results)}–"
          f"{max(r['d_star'] for r in results)}")


if __name__ == "__main__":
    main()
